package com.rahmanarifofficial.coronastats.datasource

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}