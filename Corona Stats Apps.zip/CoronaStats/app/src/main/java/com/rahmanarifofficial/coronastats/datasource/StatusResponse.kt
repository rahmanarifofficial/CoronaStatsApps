package com.rahmanarifofficial.coronastats.datasource

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}