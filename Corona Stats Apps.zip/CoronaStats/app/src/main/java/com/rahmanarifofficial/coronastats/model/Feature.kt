package com.rahmanarifofficial.coronastats.model

data class Feature(
    val attributes: Attributes? =null
)