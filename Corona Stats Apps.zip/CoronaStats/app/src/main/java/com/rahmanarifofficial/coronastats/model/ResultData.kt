package com.rahmanarifofficial.coronastats.model

data class ResultData(
    val features: List<Feature>?=null
)